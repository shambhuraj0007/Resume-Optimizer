const iframe = document.getElementById("app-frame");

// Wait for iframe to load
iframe.onload = () => {
    // Check storage for the text saved by background.js
    chrome.storage.local.get(["selectedJD"], (result) => {
        if (result.selectedJD) {
            console.log("Found JD in storage, attempting to send...");
            const jdText = result.selectedJD;

            // Use a small interval to ensure the message is received
            // (The iframe might not have registered its listener yet)
            let attempts = 0;
            const interval = setInterval(() => {
                attempts++;
                iframe.contentWindow.postMessage(
                    { type: "SET_JD", text: jdText },
                    "https://shortlistai.xyz" // Automatically updated by sync script
                );

                if (attempts > 50) { // Stop after 5 seconds
                    clearInterval(interval);
                    chrome.storage.local.remove(["selectedJD"]);
                }
            }, 100);

            // Listen for acknowledgment to stop the interval early
            window.addEventListener("message", (event) => {
                if (event.data?.type === "JD_RECEIVED") {
                    console.log("Iframe acknowledged receipt.");
                    clearInterval(interval);
                    chrome.storage.local.remove(["selectedJD"]);
                }
            });
        }
    });
};
